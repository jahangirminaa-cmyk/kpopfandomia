import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { createServer } from "http";
import { Server } from "socket.io";
import { v4 as uuidv4 } from "uuid";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: { origin: "*" },
  });

  app.use(express.json());

  // --- DATABASE SCHEMA MOCKS (In-memory for dev/boilerplate) ---
  const users: Record<string, any> = {}; // { id: { id, fullName, username, email, profilePic } }
  const messages: Record<string, any[]> = {}; // roomId -> Message[]

  // Real-time Socket.io logic
  io.on("connection", (socket) => {
    console.log("Client connected:", socket.id);

    // Join a specific fandom room
    socket.on("join_room", ({ roomId, userId }) => {
      socket.join(roomId);
      console.log(`User ${userId} joined room ${roomId}`);
      
      // Send chat history to user
      if (!messages[roomId]) messages[roomId] = [];
      socket.emit("room_history", messages[roomId].slice(-50)); // Send last 50
    });

    // Handle incoming messages
    socket.on("send_message", ({ roomId, text, userId }) => {
      const user = users[userId];
      if (!user) return;

      const newMessage = {
        id: uuidv4(),
        roomId,
        text,
        senderId: user.id,
        senderUsername: user.username,
        senderProfilePic: user.profilePic,
        createdAt: new Date().toISOString(),
        isPinned: false,
      };

      if (!messages[roomId]) messages[roomId] = [];
      messages[roomId].push(newMessage);

      // Broadcast to room
      io.to(roomId).emit("new_message", newMessage);
    });

    socket.on("pin_message", ({ roomId, messageId }) => {
      const roomMsgs = messages[roomId] || [];
      const msg = roomMsgs.find(m => m.id === messageId);
      if (msg) {
        const pinnedCount = roomMsgs.filter(m => m.isPinned).length;
        if (pinnedCount < 3 && !msg.isPinned) {
          msg.isPinned = true;
          io.to(roomId).emit("message_pinned", msg);
        } else if (pinnedCount >= 3) {
          socket.emit("error_message", "Maximum 3 pinned messages allowed.");
        }
      }
    });

    socket.on("unpin_message", ({ roomId, messageId }) => {
      const roomMsgs = messages[roomId] || [];
      const msg = roomMsgs.find(m => m.id === messageId);
      if (msg && msg.isPinned) {
        msg.isPinned = false;
        io.to(roomId).emit("message_unpinned", msg);
      }
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected:", socket.id);
    });
  });

  // Basic API for Authentication Mock
  app.post("/api/auth/register", (req, res) => {
    const { fullName, username, email, password, profilePic, bio } = req.body;
    
    // Check if username exists
    const existing = Object.values(users).find(u => u.username === username);
    if (existing) {
      return res.status(400).json({ error: "Username already taken" });
    }

    const newUser = {
      id: uuidv4(),
      fullName,
      username,
      email,
      // In a real app we would hash the password
      password,
      profilePic: profilePic || "https://api.dicebear.com/7.x/avataaars/svg?seed=" + username,
      bio: bio || "K-Pop enthusiast!",
      createdAt: new Date().toISOString()
    };
    
    users[newUser.id] = newUser;
    const { password: _, ...safeUser } = newUser;
    res.json({ user: safeUser });
  });

  app.put("/api/users/:id", (req, res) => {
    const { id } = req.params;
    if (!users[id]) return res.status(404).json({ error: "User not found" });

    const { fullName, profilePic, bio } = req.body;
    users[id] = { ...users[id], fullName, profilePic, bio };
    const { password: _, ...safeUser } = users[id];

    // Optionally broadcast profile update if needed
    res.json({ user: safeUser });
  });

  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    const user = Object.values(users).find(u => u.username === username && u.password === password);
    
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const { password: _, ...safeUser } = user;
    res.json({ user: safeUser });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve static files. Express 5 requires "*all" not "*" if upgraded, but we're on 4.x
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
