export interface User {
  id: string;
  fullName: string;
  username: string; // The @ handle
  email: string;
  profilePic: string; // URL
  bio: string;
  createdAt: string;
}

export interface Message {
  id: string;
  roomId: string;
  text: string;
  senderId: string;
  senderUsername: string;
  senderProfilePic: string;
  createdAt: string;
  isPinned?: boolean;
}

export interface FandomRoom {
  id: string;
  name: string; // e.g. ARMYS, BLINKS
  group: string; // e.g. BTS, BLACKPINK
  themeColor: string; // Used for UI highlights
  imageUrl?: string; // Group picture
}

// Fixed list of Fandoms as requested
export const FANDOM_ROOMS: FandomRoom[] = [
  { id: "armys", name: "ARMYS", group: "BTS", themeColor: "from-purple-500 to-indigo-600", imageUrl: "https://images.unsplash.com/photo-1625695029671-551ee6d6d2a4?w=150&h=150&fit=crop&q=80" },
  { id: "blinks", name: "BLINKS", group: "BLACKPINK", themeColor: "from-pink-500 to-rose-600", imageUrl: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=150&h=150&fit=crop&q=80" },
  { id: "eyekons", name: "EYEKONS", group: "iKON", themeColor: "from-red-500 to-red-700", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=150&h=150&fit=crop&q=80" },
  { id: "engenes", name: "ENGENES", group: "ENHYPEN", themeColor: "from-orange-400 to-red-500", imageUrl: "https://images.unsplash.com/photo-1598387993441-a364f854c3e1?w=150&h=150&fit=crop&q=80" },
  { id: "stays", name: "STAYS", group: "Stray Kids", themeColor: "from-red-600 to-gray-900", imageUrl: "https://images.unsplash.com/photo-1493225457124-a1a2a5f5f4b5?w=150&h=150&fit=crop&q=80" },
  { id: "onces", name: "ONCES", group: "TWICE", themeColor: "from-orange-300 to-pink-400", imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=150&h=150&fit=crop&q=80" },
  { id: "midzy", name: "MIDZY", group: "ITZY", themeColor: "from-fuchsia-500 to-pink-500", imageUrl: "https://images.unsplash.com/photo-1521337581100-8ca9a73a5f79?w=150&h=150&fit=crop&q=80" },
  { id: "gllit", name: "GLLIT", group: "LIMELIGHT/MADEIN", themeColor: "from-yellow-400 to-green-500", imageUrl: "https://images.unsplash.com/photo-1470229722913-7c090be5bb10?w=150&h=150&fit=crop&q=80" },
  { id: "fearnots", name: "FEARNOTS", group: "LE SSERAFIM", themeColor: "from-slate-700 to-black", imageUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=150&h=150&fit=crop&q=80" },
  { id: "monstiez", name: "MONSTIEZ", group: "BABYMONSTER", themeColor: "from-red-600 to-rose-800", imageUrl: "https://images.unsplash.com/photo-1510515159021-d70717208f23?w=150&h=150&fit=crop&q=80" },
  { id: "coers", name: "COERS OF CORTIS", group: "Geenius", themeColor: "from-indigo-400 to-cyan-400", imageUrl: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=150&h=150&fit=crop&q=80" },
  { id: "mys", name: "MYS", group: "aespa", themeColor: "from-purple-600 to-indigo-900", imageUrl: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=150&h=150&fit=crop&q=80" },
  { id: "dive", name: "DIVE", group: "IVE", themeColor: "from-teal-400 to-emerald-500", imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&h=150&fit=crop&q=80" },
];
