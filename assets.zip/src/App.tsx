import { useState, useEffect, useRef, type FormEvent } from "react";
import { io, Socket } from "socket.io-client";
import { User, Message, FANDOM_ROOMS, FandomRoom } from "./types";
import { cn } from "./lib/utils";
import { Camera, Hash, MessageCircle, Send, LogOut, User as UserIcon, Loader2, Sun, Moon, Pin, UserCircle, Edit2, X, MoreHorizontal } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// The single socket instance.
let socket: Socket | null = null;

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    // Attempt to restore user session from local storage
    const savedUser = localStorage.getItem("kpop_chat_user");
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
    const savedTheme = localStorage.getItem("kpop_chat_theme");
    if (savedTheme === "light") {
      setIsDarkMode(false);
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(prev => {
      const next = !prev;
      localStorage.setItem("kpop_chat_theme", next ? "dark" : "light");
      if (next) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      return next;
    });
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem("kpop_chat_user", JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("kpop_chat_user");
    if (socket) {
      socket.disconnect();
      socket = null;
    }
  };

  if (!currentUser) {
    return <AuthScreen onAuthSuccess={handleAuthSuccess} />;
  }

  return <MainChatScreen currentUser={currentUser} onLogout={handleLogout} toggleTheme={toggleTheme} isDarkMode={isDarkMode} setCurrentUser={handleAuthSuccess} />;
}

function AuthScreen({ onAuthSuccess }: { onAuthSuccess: (user: User) => void }) {
  const [isLogin, setIsLogin] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Forms
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const endpoint = isLogin ? "/api/auth/login" : "/api/auth/register";
    const payload = isLogin 
      ? { username, password } 
      : { fullName, username, email, password };

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Authentication failed");
        return;
      }
      
      onAuthSuccess(data.user);
    } catch (err) {
      console.error(err);
      alert("Network error connecting to auth server");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1543389020-00e163c457ff?q=80&w=2670&auto=format&fit=crop')" }}>
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-[#0B0A10]/80 backdrop-blur-md" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel w-full max-w-sm rounded-[2rem] p-8 relative z-10 mx-4"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-tr from-pink-500 to-purple-600 rounded-full mx-auto flex items-center justify-center mb-4 shadow-[0_0_30px_rgba(236,72,153,0.5)]">
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-display font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">K-POP NATION</h1>
          <p className="text-sm text-gray-400 mt-2">Join the global fandom</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <input
                required
                type="text"
                placeholder="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 focus:bg-white/10 transition-all text-sm"
              />
              <input
                required
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 focus:bg-white/10 transition-all text-sm"
              />
            </>
          )}
          
          <input
            required
            type="text"
            placeholder="Username (e.g., @charlie_blink)"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 focus:bg-white/10 transition-all text-sm"
          />
          <input
            required
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 focus:bg-white/10 transition-all text-sm"
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-medium rounded-xl px-4 py-3 transition-transform active:scale-[0.98] flex items-center justify-center gap-2 mt-4 shadow-[0_0_20px_rgba(236,72,153,0.3)] disabled:opacity-50 disabled:pointer-events-none"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLogin ? "Log In" : "Sign Up")}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button 
            type="button" 
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm text-gray-400 hover:text-pink-400 transition-colors"
          >
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Log in"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function MainChatScreen({ currentUser, onLogout, toggleTheme, isDarkMode, setCurrentUser }: { currentUser: User; onLogout: () => void; toggleTheme: () => void; isDarkMode: boolean; setCurrentUser: (user: User) => void }) {
  const [activeRoom, setActiveRoom] = useState<FandomRoom>(FANDOM_ROOMS[0]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Connect to socket
  useEffect(() => {
    // Determine the socket url: in dev it is handled by the proxy if set up, or just "/"
    socket = io();

    socket.on("connect", () => {
      console.log("Connected to server...");
      // Re-join active room automatically
      socket?.emit("join_room", { roomId: activeRoom.id, userId: currentUser.id });
    });

    socket.on("room_history", (history: Message[]) => {
      setMessages(history);
      scrollToBottom();
    });

    socket.on("new_message", (msg: Message) => {
      if (msg.roomId === activeRoom.id) {
        setMessages((prev) => [...prev, msg]);
        scrollToBottom();
      }
    });

    socket.on("message_pinned", (msg: Message) => {
      if (msg.roomId === activeRoom.id) {
        setMessages((prev) => prev.map(m => m.id === msg.id ? { ...m, isPinned: true } : m));
      }
    });

    socket.on("message_unpinned", (msg: Message) => {
      if (msg.roomId === activeRoom.id) {
        setMessages((prev) => prev.map(m => m.id === msg.id ? { ...m, isPinned: false } : m));
      }
    });

    socket.on("error_message", (err: string) => {
      alert(err);
    });

    return () => {
      socket?.off("connect");
      socket?.off("room_history");
      socket?.off("new_message");
      socket?.off("message_pinned");
      socket?.off("message_unpinned");
      socket?.off("error_message");
    };
  }, [currentUser.id, activeRoom.id]);

  useEffect(() => {
    if (socket?.connected) {
      setMessages([]); // clear local messages while fetching new history
      socket.emit("join_room", { roomId: activeRoom.id, userId: currentUser.id });
    }
  }, [activeRoom.id, currentUser.id]);

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleSendMessage = (e: FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    socket?.emit("send_message", {
      roomId: activeRoom.id,
      text: inputText,
      userId: currentUser.id
    });

    setInputText("");
  };

  const togglePin = (msg: Message) => {
    if (msg.isPinned) {
      socket?.emit("unpin_message", { roomId: activeRoom.id, messageId: msg.id });
    } else {
      socket?.emit("pin_message", { roomId: activeRoom.id, messageId: msg.id });
    }
  };

  const pinnedMessages = messages.filter(m => m.isPinned);

  return (
    <div className="h-screen w-full flex relative">
      {/* Background ambient lighting */}
      <div 
        className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-pink-600/20 rounded-full blur-[120px] pointer-events-none transition-colors duration-1000"
        style={{ background: `linear-gradient(to right bottom, var(--tw-gradient-stops))` }}
      />
      <div 
        className="fixed bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] pointer-events-none transition-colors duration-1000 opacity-20"
        style={{ backgroundImage: `linear-gradient(to top left, var(--tw-gradient-from), var(--tw-gradient-to))` }}
      />

      {/* Sidebar - Fandom Navigation */}
      <Sidebar 
        activeRoom={activeRoom} 
        setActiveRoom={(room) => {
          setActiveRoom(room);
          setShowProfile(false);
        }}
        currentUser={currentUser}
        onLogout={onLogout}
        onProfileClick={() => setShowProfile(true)}
      />

      {/* Main Area */}
      <div className="flex-1 flex flex-col relative z-10 m-0 glass-panel rounded-none overflow-hidden border-none shadow-none bg-transparent">
        
        {showProfile ? (
          <ProfilePage currentUser={currentUser} onClose={() => setShowProfile(false)} onUpdate={setCurrentUser} />
        ) : (
          <>
            {/* Chat Header */}
        <header className="h-20 px-8 flex items-center justify-between border-b border-white/10 bg-white/[0.02] backdrop-blur-md sticky top-0 z-20">
          <div>
            <h2 className="text-lg font-bold flex items-center gap-2">
              <span className="text-[#FF007A]">#</span> {activeRoom.name}
              <span className="px-2 py-0.5 bg-pink-500/20 text-pink-400 text-[10px] rounded uppercase font-black tracking-tighter">Hot</span>
            </h2>
            <p className="text-xs text-white/40">{activeRoom.group} Global Chat</p>
          </div>
          
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center -space-x-3 mt-1">
                <div className="w-8 h-8 rounded-full border-2 border-white dark:border-[#0A0518] bg-blue-500"></div>
                <div className="w-8 h-8 rounded-full border-2 border-white dark:border-[#0A0518] bg-red-500"></div>
                <div className="w-8 h-8 rounded-full border-2 border-white dark:border-[#0A0518] bg-yellow-500"></div>
                <div className="w-8 h-8 rounded-full border-2 border-white dark:border-[#0A0518] bg-black/10 dark:bg-white/10 flex items-center justify-center text-[10px] font-bold">+1k</div>
              </div>
              <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-gray-500 dark:text-gray-400 transition-colors mt-2" title="Toggle Theme">
                {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
        </header>

        {/* Pinned Messages Area */}
        {pinnedMessages.length > 0 && (
          <div className="bg-white/40 dark:bg-black/40 border-b border-white/20 dark:border-white/10 p-3 px-8 flex flex-col gap-2 shrink-0">
            <div className="flex items-center gap-2 text-xs font-bold text-pink-500">
              <Pin className="w-3 h-3" /> Pinned Messages ({pinnedMessages.length}/3)
            </div>
            <div className="flex gap-4 overflow-x-auto custom-scrollbar pb-1">
              {pinnedMessages.map(msg => (
                <div key={msg.id} className="min-w-[250px] max-w-[300px] bg-white/50 dark:bg-white/5 rounded-lg p-3 text-sm flex flex-col gap-1 border border-white/40 dark:border-white/5 truncate shrink-0 relative group">
                  <div className="text-xs font-bold truncate opacity-80">@{msg.senderUsername}</div>
                  <div className="truncate text-gray-800 dark:text-gray-200">{msg.text}</div>
                  <button onClick={() => togglePin(msg)} className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 hover:bg-black/10 dark:hover:bg-white/10 rounded">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-6">
          {messages.map((msg, idx) => {
            const isMe = msg.senderId === currentUser.id;
            const showProfilePic = idx === 0 || messages[idx - 1].senderId !== msg.senderId;

            return (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={msg.id} 
                className={cn("flex gap-4 max-w-3xl group relative", isMe ? "ml-auto flex-row-reverse" : "")}
              >
                {/* Profile Pic (Only show if new sender) */}
                <div className="w-10 flex-shrink-0 flex justify-center sticky top-0 h-10">
                  {showProfilePic && (
                    <button 
                      onClick={() => setSelectedUser(selectedUser?.id === msg.senderId ? null : {
                        id: msg.senderId,
                        fullName: msg.senderUsername, // Ideally look up full user
                        username: msg.senderUsername,
                        email: "",
                        profilePic: msg.senderProfilePic,
                        bio: "K-Pop enthusiast!",
                        createdAt: msg.createdAt,
                      })}
                      className="transition-transform hover:scale-105"
                    >
                      <img 
                        src={msg.senderProfilePic} 
                        alt={msg.senderUsername} 
                        className="w-10 h-10 rounded-full border border-white/20 object-cover shadow-lg"
                      />
                    </button>
                  )}
                </div>

                <div className={cn("flex flex-col gap-1", isMe ? "items-end" : "items-start")}>
                  {showProfilePic && (
                    <div className={cn("flex items-center gap-2 mb-1", isMe && "flex-row-reverse")}>
                      <span className={cn("text-xs font-bold", isMe ? "text-pink-500 dark:text-pink-400" : "text-indigo-600 dark:text-indigo-400")}>{isMe ? "Me" : `@${msg.senderUsername}`}</span>
                      <span className="text-[9px] opacity-40 uppercase">{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  )}
                  <div className={cn(
                    "p-3 text-sm leading-relaxed relative",
                    isMe 
                      ? "bg-gradient-to-br from-[#FF007A] to-[#BC13FE] rounded-2xl rounded-tr-none shadow-[0_5px_20px_rgba(255,0,122,0.3)] text-white" 
                      : "bg-white dark:bg-white/5 backdrop-blur-xl border border-gray-100 dark:border-white/10 rounded-2xl rounded-tl-none shadow-sm dark:text-white"
                  )}>
                    {msg.text}
                    
                    {/* Pin action toggle context menu */}
                    <button 
                      onClick={() => togglePin(msg)}
                      className={cn(
                        "absolute top-1/2 -translate-y-1/2 p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity bg-white dark:bg-gray-800 shadow-md",
                        isMe ? "-left-10" : "-right-10"
                      )}
                      title={msg.isPinned ? "Unpin message" : "Pin message"}
                    >
                      <Pin className={cn("w-3 h-3", msg.isPinned ? "fill-pink-500 text-pink-500" : "text-gray-500")} />
                    </button>
                  </div>
                </div>

                {/* Mini Profile Popover (Very naive placement for demo) */}
                {selectedUser?.id === msg.senderId && showProfilePic && (
                  <div className={cn("absolute top-12 z-50 w-64 glass-panel rounded-2xl p-4 flex flex-col items-center shadow-2xl", isMe ? "right-12" : "left-12")}>
                    <button onClick={() => setSelectedUser(null)} className="absolute top-2 right-2 p-1 opacity-50 hover:opacity-100"><X className="w-4 h-4" /></button>
                    <img src={msg.senderProfilePic} className="w-16 h-16 rounded-full border-2 border-pink-500 object-cover mb-2" />
                    <div className="font-bold">@{msg.senderUsername}</div>
                    <div className="text-xs opacity-60 text-center mt-1">K-Pop fan in #{activeRoom.name}</div>
                  </div>
                )}
              </motion.div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-6">
          <form onSubmit={handleSendMessage} className="bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl p-2 flex items-center gap-4 backdrop-blur-xl shadow-lg dark:shadow-none">
            <button type="button" className="w-10 h-10 flex items-center justify-center opacity-40 hover:opacity-100">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </button>
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Message #${activeRoom.name}...`}
              className="flex-1 bg-transparent border-none outline-none text-sm py-2 px-0 placeholder:opacity-40"
            />
            <button 
              type="submit"
              disabled={!inputText.trim()}
              className="px-6 py-2.5 bg-gradient-to-r from-[#FF007A] to-[#BC13FE] rounded-xl text-xs font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(255,0,122,0.4)] disabled:opacity-30 disabled:grayscale transition-all hover:scale-105 active:scale-95 text-white"
            >
              Send
            </button>
          </form>
        </div>
          </>
        )}
      </div>
    </div>
  );
}

function Sidebar({ activeRoom, setActiveRoom, currentUser, onLogout, onProfileClick }: { activeRoom: FandomRoom; setActiveRoom: (room: FandomRoom) => void; currentUser: User; onLogout: () => void; onProfileClick: () => void }) {
  return (
    <aside className="w-64 bg-[#2D164E] dark:bg-[#120524] text-white border-r border-purple-500/20 flex flex-col backdrop-blur-xl z-20 shrink-0 shadow-[4px_0_24px_rgba(45,22,78,0.2)] dark:shadow-none">
      <div className="p-6 border-b border-purple-500/20 flex items-center gap-3">
        <div className="w-10 h-10 bg-gradient-to-tr from-[#FF007A] to-[#BC13FE] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(255,0,122,0.4)]">
          <span className="font-black text-xl text-white">K</span>
        </div>
        <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-pink-400 to-white bg-clip-text text-transparent">K-CHAT</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-1 custom-scrollbar">
        <div className="text-[10px] uppercase tracking-widest text-purple-200/60 mb-2 px-2">Fandom Rooms</div>
        {FANDOM_ROOMS.map((room) => {
          const isActive = activeRoom.id === room.id;
          return (
            <button
              key={room.id}
              onClick={() => setActiveRoom(room)}
              className={cn(
                "w-full flex items-center gap-3 p-3 transition-all group text-left",
                isActive 
                  ? "bg-gradient-to-r from-[#FF007A]/30 to-transparent border-l-4 border-[#FF007A] rounded-r-lg" 
                  : "hover:bg-white/10 rounded-lg opacity-85 hover:opacity-100"
              )}
            >
              {room.imageUrl ? (
                <img src={room.imageUrl} alt={room.group} className={cn("w-8 h-8 rounded-full border object-cover shrink-0", isActive ? "border-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.5)]" : "border-purple-300/30")} />
              ) : (
                <div className={cn(
                  "w-8 h-8 rounded-full border flex items-center justify-center text-xs font-bold shrink-0",
                  isActive ? "border-pink-400 bg-pink-500/20 text-white" : "border-purple-300/30 bg-white/5 text-purple-200"
                )}>
                  {room.name.substring(0, 2).toUpperCase()}
                </div>
              )}
              
              <div className="flex-1 overflow-hidden">
                <div className={cn("text-sm uppercase tracking-wider truncate", isActive ? "font-black text-white" : "font-bold text-white/80 group-hover:text-white")}>
                  {room.name}
                </div>
                {isActive && <div className="text-[10px] text-pink-300 font-bold">Active Room</div>}
              </div>
            </button>
          );
        })}
      </div>

      {/* Current User Mini Profile */}
      <div className="p-4 border-t border-purple-500/20 bg-black/20 hover:bg-black/40 backdrop-blur-2xl flex items-center gap-3 relative group cursor-pointer transition-colors" onClick={onProfileClick}>
        <div className="relative shrink-0">
          <img src={currentUser.profilePic} alt={currentUser.username} className="w-10 h-10 rounded-full border-2 border-[#BC13FE] object-cover" />
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#2D164E] dark:border-[#120524]"></div>
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-bold truncate">@{currentUser.username}</div>
          <div className="text-[10px] text-purple-200/60 truncate max-w-[120px]">{currentUser.bio || "Online"}</div>
        </div>
        <button 
          onClick={(e) => { e.stopPropagation(); onLogout(); }}
          className="opacity-0 group-hover:opacity-100 p-2 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-opacity absolute right-4"
          title="Log out"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}

function ProfilePage({ currentUser, onClose, onUpdate }: { currentUser: User; onClose: () => void; onUpdate: (u: User) => void }) {
  const [fullName, setFullName] = useState(currentUser.fullName);
  const [profilePic, setProfilePic] = useState(currentUser.profilePic);
  const [bio, setBio] = useState(currentUser.bio || "");
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/users/${currentUser.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, profilePic, bio }),
      });
      if (res.ok) {
        const data = await res.json();
        onUpdate(data.user);
        onClose();
      } else {
        alert("Failed to update profile");
      }
    } catch (e) {
      alert("Error updating profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-8 overflow-y-auto">
      <div className="max-w-2xl w-full mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold font-display">Edit Profile</h2>
          <button onClick={onClose} className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full transition-colors opacity-70">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-6">
          <div className="relative">
            <img src={profilePic} className="w-24 h-24 rounded-full object-cover border-4 border-pink-500 shadow-xl" />
            <div className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-indigo-500 border-2 border-white dark:border-[#0A0518] flex items-center justify-center cursor-pointer">
              <Camera className="w-4 h-4 text-white" />
            </div>
          </div>
          <div>
            <h3 className="text-lg font-bold">@{currentUser.username}</h3>
            <p className="text-sm opacity-60">Member since {new Date(currentUser.createdAt).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-bold opacity-80 block mb-2">Display Name</label>
            <input 
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              className="w-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 shadow-sm"
            />
          </div>
          <div>
            <label className="text-sm font-bold opacity-80 block mb-2">Profile Picture URL</label>
            <input 
              value={profilePic}
              onChange={e => setProfilePic(e.target.value)}
              className="w-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 shadow-sm"
            />
          </div>
          <div>
            <label className="text-sm font-bold opacity-80 block mb-2">Short Bio</label>
            <textarea 
              value={bio}
              onChange={e => setBio(e.target.value)}
              rows={3}
              placeholder="Tell us about your favorite biases..."
              className="w-full bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-3 outline-none focus:border-pink-500/50 shadow-sm resize-none"
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button onClick={onClose} className="px-6 py-2.5 rounded-xl font-bold opacity-70 hover:opacity-100 transition-opacity">Cancel</button>
          <button onClick={handleSave} disabled={loading} className="px-6 py-2.5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-xl font-bold text-white shadow-[0_0_15px_rgba(255,0,122,0.4)] disabled:opacity-50">
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

